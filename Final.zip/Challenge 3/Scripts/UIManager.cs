// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.UI;
// using System;
// using TMPro;

// public class UIManager : MonoBehaviour
// {
//     [SerializeField] public int _playerScore;
//     [SerializeField] public TMP_Text _scoreText;
//     [SerializeField] public TMP_Text _clockText;
//     public UIManager _uiManager;

//     // Start is called before the first frame update
//     void Start()
//     {
//         _playerScore = 0;
//         _uiManager = GameObject.Find("Canvas").GetComponent<UIManager>();
//         if (_uiManager != null){
//             Debug.LogError("The UI manager is NULL!");
//         }
//     }

//     // Update is called once per frame
//     void Update()
//     {
//         _clockText.Text = DateTime.Now.ToString();
//         if (other.tag == "Tusk"){
//             Destroy(other.gameObject);
//             if (_uiManager != null){
//                 _uiManager.UpdateScore(1);
//             }
//             _enemyCollider.enabled = false;
//             _spriteRenderer.color = Color.blue;
//             _enemyRB.gravityScale = 1f;
//         }
//     }

//     void UpdateScore(int points)
//     {
//         _playerScore += points;
//         _scoreText.Text = "Score : " + _playerScore.ToString();
//     }
// }

    
